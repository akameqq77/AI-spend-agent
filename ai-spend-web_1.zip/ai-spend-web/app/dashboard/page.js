'use client';

import { useEffect, useState, useMemo, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '../../lib/supabaseClient';

const CATEGORIES = [
  'Код / разработка', 'Написание текстов', 'Продажи / CRM', 'Дизайн',
  'Аналитика данных', 'Поддержка клиентов', 'Общий AI-ассистент', 'Другое'
];

const EMPTY_FORM = { name: '', owner: '', category: CATEGORIES[0], cost: '', licenses: '', active: '', renewal: '', notes: '' };

function money(n) { return '$' + Math.round(n).toLocaleString('en-US'); }
function pct(n) { return Math.round(n) + '%'; }
function daysUntil(dateStr) {
  if (!dateStr) return null;
  const d = new Date(dateStr);
  const now = new Date();
  d.setHours(0, 0, 0, 0); now.setHours(0, 0, 0, 0);
  return Math.round((d - now) / (1000 * 60 * 60 * 24));
}

export default function Dashboard() {
  const router = useRouter();
  const [session, setSession] = useState(undefined);
  const [tools, setTools] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState(EMPTY_FORM);
  const [editingId, setEditingId] = useState(null);
  const [formError, setFormError] = useState('');
  const [search, setSearch] = useState('');
  const [filterCat, setFilterCat] = useState('');

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) { router.replace('/login'); return; }
      setSession(session);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!session) router.replace('/login');
      setSession(session);
    });
    return () => listener.subscription.unsubscribe();
  }, [router]);

  const fetchTools = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase.from('tools').select('*').order('created_at', { ascending: true });
    if (!error) setTools(data || []);
    setLoading(false);
  }, []);

  useEffect(() => {
    if (session) fetchTools();
  }, [session, fetchTools]);

  async function handleLogout() {
    await supabase.auth.signOut();
    router.replace('/login');
  }

  const enriched = useMemo(() => tools.map(t => {
    const util = t.licenses > 0 ? (t.active / t.licenses) * 100 : 0;
    const perActive = t.active > 0 ? t.cost / t.active : t.cost;
    return { ...t, util, perActive };
  }), [tools]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return enriched.filter(t =>
      (!q || t.name.toLowerCase().includes(q) || (t.owner || '').toLowerCase().includes(q)) &&
      (!filterCat || t.category === filterCat)
    );
  }, [enriched, search, filterCat]);

  const stats = useMemo(() => {
    const total = enriched.reduce((s, t) => s + Number(t.cost), 0);
    const waste = enriched.filter(t => t.licenses > 0 && t.util < 30).reduce((s, t) => s + Number(t.cost), 0);
    const renewalsSoon = enriched.filter(t => {
      const d = daysUntil(t.renewal);
      return d !== null && d >= 0 && d <= 60;
    });
    const avgUtil = enriched.length > 0 ? enriched.reduce((s, t) => s + t.util, 0) / enriched.length : 0;
    return { total, waste, renewalsCount: renewalsSoon.length, avgUtil };
  }, [enriched]);

  const overlaps = useMemo(() => {
    const byCategory = {};
    tools.forEach(t => {
      if (!byCategory[t.category]) byCategory[t.category] = [];
      byCategory[t.category].push(t.name);
    });
    return Object.entries(byCategory).filter(([, names]) => names.length > 1);
  }, [tools]);

  const lowUtilTools = useMemo(() => enriched.filter(t => t.licenses > 0 && t.util < 30), [enriched]);

  function resetForm() {
    setForm(EMPTY_FORM);
    setEditingId(null);
    setFormError('');
  }

  function startEdit(t) {
    setEditingId(t.id);
    setForm({
      name: t.name, owner: t.owner || '', category: t.category, cost: t.cost,
      licenses: t.licenses, active: t.active, renewal: t.renewal || '', notes: t.notes || ''
    });
  }

  async function handleDelete(id) {
    await supabase.from('tools').delete().eq('id', id);
    if (editingId === id) resetForm();
    fetchTools();
  }

  async function handleSubmit(e) {
    e.preventDefault();
    const name = form.name.trim();
    const cost = parseFloat(form.cost);
    const licenses = parseInt(form.licenses, 10);
    const active = parseInt(form.active, 10);

    if (!name) return setFormError('Укажите название инструмента');
    if (isNaN(cost) || cost < 0) return setFormError('Укажите корректную стоимость');
    if (isNaN(licenses) || licenses < 0) return setFormError('Укажите количество лицензий');
    if (isNaN(active) || active < 0) return setFormError('Укажите количество активных пользователей');
    if (active > licenses) return setFormError('Активных пользователей не может быть больше лицензий');
    setFormError('');

    const record = {
      name, owner: form.owner.trim(), category: form.category, cost, licenses, active,
      renewal: form.renewal || null, notes: form.notes.trim(),
      updated_at: new Date().toISOString()
    };

    if (editingId) {
      await supabase.from('tools').update(record).eq('id', editingId);
    } else {
      await supabase.from('tools').insert([{ ...record, created_by: session.user.id }]);
    }
    resetForm();
    fetchTools();
  }

  function exportCsv() {
    if (tools.length === 0) return;
    const headers = ['Название', 'Ответственный', 'Категория', 'Стоимость $/мес', 'Лицензии', 'Активные', 'Загрузка %', '$/активный', 'Дата продления', 'Заметка'];
    const rows = enriched.map(t => [t.name, t.owner || '', t.category, t.cost, t.licenses, t.active, Math.round(t.util), Math.round(t.perActive), t.renewal || '', t.notes || '']);
    const csv = [headers, ...rows].map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'ai-tools-registry.csv'; a.click();
    URL.revokeObjectURL(url);
  }

  if (session === undefined || loading) {
    return <div className="page"><p style={{ color: 'var(--ink-soft)' }}>Загрузка…</p></div>;
  }

  return (
    <div className="page">
      <div className="masthead">
        <div>
          <h1>Реестр AI-инструментов</h1>
          <p>Общий реестр команды — обновляется у всех участников в реальном времени</p>
        </div>
        <div className="actions">
          <span className="user-email">{session.user.email}</span>
          <button className="secondary" style={{ margin: 0 }} onClick={handleLogout}>Выйти</button>
        </div>
      </div>

      <div className="ledger-strip">
        <div className="cell">
          <div className="label">Совокупные затраты / мес</div>
          <div className="value">{money(stats.total)}</div>
          <div className="sub">{tools.length} {tools.length === 1 ? 'инструмент' : 'инструментов'}</div>
        </div>
        <div className="cell">
          <div className="label">Расходы на низкое использование</div>
          <div className={'value' + (stats.waste > 0 ? ' warn' : '')}>{money(stats.waste)}</div>
          <div className="sub">меньше 30% лицензий активны</div>
        </div>
        <div className="cell">
          <div className="label">Продление в ближайшие 60 дней</div>
          <div className="value">{stats.renewalsCount}</div>
          <div className="sub">инструментов</div>
        </div>
        <div className="cell">
          <div className="label">Средняя загрузка лицензий</div>
          <div className="value">{pct(stats.avgUtil)}</div>
          <div className="sub">по всем инструментам</div>
        </div>
      </div>

      {lowUtilTools.length > 0 && (
        <div className="recommendation">
          Пересмотр лицензий у <b>{lowUtilTools.length}</b> {lowUtilTools.length === 1 ? 'инструмента' : 'инструментов'} с загрузкой ниже 30% может сэкономить до <b>{money(lowUtilTools.reduce((s, t) => s + Number(t.cost), 0))}</b> в месяц. Начните с: {lowUtilTools.slice(0, 3).map(t => t.name).join(', ')}.
        </div>
      )}

      {overlaps.length > 0 && (
        <div className="overlap-banner">
          {overlaps.map(([cat, names]) => (
            <div key={cat}><b>{cat}:</b> {names.join(', ')} — возможное дублирование функций, стоит рассмотреть консолидацию.</div>
          ))}
        </div>
      )}

      <div className="section-title">Инструменты <span className="count">{tools.length} {tools.length === 1 ? 'запись' : 'записей'}</span></div>

      <div className="toolbar">
        <input type="text" placeholder="Поиск по названию или ответственному" value={search} onChange={e => setSearch(e.target.value)} />
        <select value={filterCat} onChange={e => setFilterCat(e.target.value)}>
          <option value="">Все категории</option>
          {[...new Set(tools.map(t => t.category))].map(c => <option key={c} value={c}>{c}</option>)}
        </select>
        <button className="ghost" onClick={exportCsv}>Экспорт CSV</button>
      </div>

      <table>
        <thead>
          <tr>
            <th>Инструмент</th><th>Ответственный</th><th>Категория</th>
            <th style={{ textAlign: 'right' }}>$/мес</th><th style={{ textAlign: 'right' }}>Лицензии</th>
            <th>Загрузка</th><th style={{ textAlign: 'right' }}>$/активный</th><th>Продление</th><th></th>
          </tr>
        </thead>
        <tbody>
          {filtered.length === 0 ? (
            <tr className="empty-row"><td colSpan={9}>{tools.length === 0 ? 'Записей пока нет — добавьте первый инструмент ниже' : 'Ничего не найдено по текущему фильтру'}</td></tr>
          ) : filtered.map(t => {
            const days = daysUntil(t.renewal);
            let utilClass = t.util < 30 ? 'critical' : t.util < 60 ? 'low' : '';
            return (
              <tr key={t.id}>
                <td className="name" style={{ cursor: 'pointer' }} onClick={() => startEdit(t)}>
                  {t.name}
                  {t.util < 30 && t.licenses > 0 && <div><span className="flag low">низкая загрузка</span></div>}
                </td>
                <td className="owner">{t.owner || '—'}</td>
                <td className="cat">{t.category}</td>
                <td className="num">{money(t.cost)}</td>
                <td className="num">{t.active}/{t.licenses}</td>
                <td>
                  <div className="util-bar">
                    <div className="util-track"><div className={'util-fill ' + utilClass} style={{ width: Math.min(t.util, 100) + '%' }} /></div>
                    <span className="util-pct">{pct(t.util)}</span>
                  </div>
                </td>
                <td className="num">{money(t.perActive)}</td>
                <td>
                  {t.renewal
                    ? (days !== null && days <= 60 && days >= 0
                      ? <span className="flag soon">{new Date(t.renewal).toLocaleDateString('ru-RU')} · {days} дн</span>
                      : <span style={{ fontSize: 12, color: 'var(--ink-soft)' }}>{new Date(t.renewal).toLocaleDateString('ru-RU')}</span>)
                    : <span style={{ color: 'var(--ink-faint)', fontSize: 12 }}>—</span>}
                </td>
                <td className="row-actions">
                  <button onClick={() => startEdit(t)} aria-label="Редактировать">edit</button>
                  <button className="danger-hover" onClick={() => handleDelete(t.id)} aria-label="Удалить">del</button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>

      <div className="section-title">{editingId ? 'Редактировать инструмент' : 'Добавить инструмент'}</div>
      <form className="add-form" onSubmit={handleSubmit}>
        <div className="grid">
          <div><label>Название</label><input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="GitHub Copilot" /></div>
          <div><label>Ответственный / отдел</label><input value={form.owner} onChange={e => setForm({ ...form, owner: e.target.value })} placeholder="Инженерия" /></div>
          <div><label>Стоимость $/мес</label><input type="number" min="0" value={form.cost} onChange={e => setForm({ ...form, cost: e.target.value })} placeholder="1200" /></div>
          <div><label>Лицензий куплено</label><input type="number" min="0" value={form.licenses} onChange={e => setForm({ ...form, licenses: e.target.value })} placeholder="50" /></div>
          <div><label>Активных пользователей</label><input type="number" min="0" value={form.active} onChange={e => setForm({ ...form, active: e.target.value })} placeholder="12" /></div>
          <div><label>Дата продления</label><input type="date" value={form.renewal} onChange={e => setForm({ ...form, renewal: e.target.value })} /></div>
        </div>
        <div className="grid2">
          <div>
            <label>Категория</label>
            <select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })}>
              {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div><label>Заметка (необязательно)</label><input value={form.notes} onChange={e => setForm({ ...form, notes: e.target.value })} placeholder="Например: обсудить скидку при продлении" /></div>
        </div>
        <div className="footer-row">
          <span className="error-msg">{formError}</span>
          <div>
            {editingId && <button type="button" className="secondary" onClick={resetForm}>Отменить</button>}
            <button type="submit" className="primary">{editingId ? 'Сохранить изменения' : 'Добавить в реестр'}</button>
          </div>
        </div>
      </form>

      <div className="footnote">Данные общие для всех, кто вошёл под аккаунтом компании. Кликните по строке, чтобы отредактировать.</div>
    </div>
  );
}
