import './globals.css';

export const metadata = {
  title: 'AI Spend Ledger',
  description: 'Учёт затрат на AI-инструменты компании'
};

export default function RootLayout({ children }) {
  return (
    <html lang="ru">
      <body>{children}</body>
    </html>
  );
}
