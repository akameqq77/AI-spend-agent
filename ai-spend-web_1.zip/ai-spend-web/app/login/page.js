'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '../../lib/supabaseClient';

export default function LoginPage() {
  const router = useRouter();
  const [mode, setMode] = useState('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [info, setInfo] = useState('');

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    setInfo('');

    if (!email.trim() || !password) {
      setError('Заполните email и пароль');
      return;
    }
    if (password.length < 6) {
      setError('Пароль должен быть не короче 6 символов');
      return;
    }

    setLoading(true);
    if (mode === 'signin') {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      setLoading(false);
      if (error) {
        setError('Неверный email или пароль');
        return;
      }
      router.replace('/dashboard');
    } else {
      const { error } = await supabase.auth.signUp({ email, password });
      setLoading(false);
      if (error) {
        setError(error.message);
        return;
      }
      setInfo('Аккаунт создан. Проверьте почту для подтверждения, затем войдите.');
      setMode('signin');
    }
  }

  return (
    <div className="page">
      <div className="auth-page">
        <h1>AI Spend Ledger</h1>
        <p>{mode === 'signin' ? 'Войдите в общий реестр команды' : 'Создайте аккаунт для команды'}</p>

        <form onSubmit={handleSubmit}>
          <label htmlFor="email">Email</label>
          <input id="email" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="name@company.com" />

          <label htmlFor="password">Пароль</label>
          <input id="password" type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Минимум 6 символов" />

          {error && <p className="error-msg" style={{ marginTop: 12 }}>{error}</p>}
          {info && <p style={{ marginTop: 12, fontSize: 13, color: '#22423A' }}>{info}</p>}

          <button className="primary" type="submit" disabled={loading}>
            {loading ? 'Подождите…' : mode === 'signin' ? 'Войти' : 'Зарегистрироваться'}
          </button>
        </form>

        <div className="auth-toggle">
          {mode === 'signin' ? (
            <>Нет аккаунта? <button onClick={() => { setMode('signup'); setError(''); }}>Зарегистрироваться</button></>
          ) : (
            <>Уже есть аккаунт? <button onClick={() => { setMode('signin'); setError(''); }}>Войти</button></>
          )}
        </div>
      </div>
    </div>
  );
}
