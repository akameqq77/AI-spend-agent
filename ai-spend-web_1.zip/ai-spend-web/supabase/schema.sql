-- Выполни этот скрипт в Supabase: Dashboard -> SQL Editor -> New query -> вставь и нажми Run

create table if not exists tools (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  owner text,
  category text not null,
  cost numeric not null default 0,
  licenses integer not null default 0,
  active integer not null default 0,
  renewal date,
  notes text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Включаем защиту на уровне строк
alter table tools enable row level security;

-- Любой залогиненный пользователь видит все записи команды
create policy "Authenticated users can view all tools"
  on tools for select
  to authenticated
  using (true);

-- Любой залогиненный пользователь может добавлять записи
create policy "Authenticated users can insert tools"
  on tools for insert
  to authenticated
  with check (true);

-- Любой залогиненный пользователь может редактировать записи
create policy "Authenticated users can update tools"
  on tools for update
  to authenticated
  using (true);

-- Любой залогиненный пользователь может удалять записи
create policy "Authenticated users can delete tools"
  on tools for delete
  to authenticated
  using (true);
